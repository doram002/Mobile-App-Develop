///  PROGRAMMER: David Oramas
//  PANTHERID: 1234567
//  CLASS:          COP 465501 MW 5:00
//  INSTRUCTOR:     Steve Luis  ECS 282
//  ASSIGNMENT:     #2
//  DUE:            Thursday 01/29/2014
//
#import "GameBoard.h"

@implementation GameBoard


@synthesize labelManager;

@synthesize  state;



- (id)init
{
    self = [super init];
    if (self) {
       
        
        state = [[NSMutableArray alloc] initWithObjects:@"", @"", @"", @"", @"", @"", @"", @"", @"", nil];
     
       
      
        
        
    }
    return self;
    

}

- (void) updateBoard:(int)position {
    
   
    
    if ( [[state objectAtIndex:position] isEqual:@""])
    {
        [state replaceObjectAtIndex:position withObject:(@"X")];
       
        temp = [UIImage imageNamed:@"x.jpg"];
        
       
        
       
    }else   if([[state objectAtIndex:position] isEqual:@"O"])
    {
        [state replaceObjectAtIndex:position withObject:(@"")];
        temp = [UIImage imageNamed:@"blank.png"];
        
        
   
    }else   {
        [state replaceObjectAtIndex:position withObject:(@"O")];
        temp = [ UIImage imageNamed:@"o.jpg"];
    
    }
    
  //  [self checkWinner];
   // [self print];
}

- (UIImage*) setImage {
    
    return temp;
}

- (UIImage*) resetBoard {
    
    for (int i = 0 ; i <  [state count]; i++) {
        [state replaceObjectAtIndex:i withObject:(@"")];
    }
    
    return [UIImage imageNamed:@"blank.png"];
}


- (void) checkWinner {
 
    
 }

@end
